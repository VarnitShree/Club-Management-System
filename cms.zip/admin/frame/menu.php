<div id="menu">
	<div class="menu-container">
	<div class="logo">
				<a href="../index.php"><img style="height: 80px; width:80px" src="../../img/club-logo.png"></a>
	</div>
		<ul class="main-nav">
			
		
			<!--<li class="notif_"><span>Notification</span></li>-->

			<li class="logout"><a href="../../logout.php">Logout&nbsp;
			<i class="fa fa-sign-out" aria-hidden="true"></i></a></li>
			<!--&nbsp;&nbsp;-->
			<br>
		</ul>
	</div>
</div>

<style type="text/css">

	.logout{
		float: right;
	}

	.notif_{
		color: #d9d9da;
	}

	.notif_:hover{
		color: #b2b2b3;
	}
	

	.fa-bell{
		cursor: pointer;
		color: #d9d9da;
		transition: 0.3s;
	}

	.fa-bell:hover{
	
	color: #b2b2b3;

	}


	.dropdown-content1 {
	margin-top: 12px;
	display: none;
    position: absolute;
    background-color: rgba(26, 26, 26, 0.8);
    min-width: 165px;
   /* box-shadow: 0px 8px 16px 0px rgba(0, 0, 0,0.2);
    */padding: 12px 0;
    z-index: 1;
    text-align: center;
	padding-bottom: 20px;
	border: 1px solid #333333;


	}

	
	.dropdown-content1 p{
		
	 	padding-top: 10px;
	}


	.dropdown1:hover .dropdown-content1{
		display: block;

	}

	.dropdown-content1 a:hover{

 	padding: 10px 50px;
 	background-color: #800060;
	}





</style>

