<?php
include '../dbconnect.php';
/*

	if(empty($_REQUEST["message"])){

		echo "Write a reply first.";

	}
	else{

		$sql='INSERT INTO message(recieverID, senderID, message, time, senderName)
				values ("'.$_REQUEST["receiver_ID"].'","'.$_REQUEST["sender_ID"].'","'.$_REQUEST["message"].'", now(),"'.$_REQUEST["sender_Name"].'")';

		$reslt = mysqli_query($db, $sql);
		
		if($reslt)
		{
			echo "Message Sent!";
		}
		else{
			echo "Something went wrong.";
		}

		*/
	}